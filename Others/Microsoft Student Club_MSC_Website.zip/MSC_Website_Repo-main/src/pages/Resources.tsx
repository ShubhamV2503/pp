import { Download, ExternalLink, FileText, Book, Code, Video, Users, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Layout from "@/components/layout/Layout";
import { motion, AnimatePresence } from "framer-motion";

const downloadableResources = [
  {
    title: "Annual Report 2024-25",
    description: "Comprehensive overview of MSC MPSTME activities, achievements, and future plans.",
    type: "PDF",
    size: "2.5 MB",
    icon: FileText,
    downloadUrl: "#", // This would link to the actual PDF
    featured: true,
  },
  {
    title: "Equinox 2.0 Proposal",
    description: "Detailed proposal for our upcoming Generative AI Symposium event.",
    type: "PDF", 
    size: "1.8 MB",
    icon: FileText,
    downloadUrl: "#",
    featured: true,
  },
  {
    title: "Club Constitution",
    description: "Official guidelines and constitution of Microsoft Student Club MPSTME.",
    type: "PDF",
    size: "950 KB",
    icon: Book,
    downloadUrl: "#",
    featured: false,
  },
  {
    title: "Event Guidelines",
    description: "Best practices and guidelines for organizing successful tech events.",
    type: "PDF",
    size: "1.2 MB",
    icon: Users,
    downloadUrl: "#",
    featured: false,
  },
];

const externalResources = [
  {
    title: "Microsoft Learn",
    description: "Official Microsoft learning platform with courses, certifications, and hands-on labs.",
    url: "https://learn.microsoft.com",
    category: "Learning Platform",
    icon: Book,
    color: "from-blue-500 to-blue-600",
  },
  {
    title: "Azure AI Studio",
    description: "Build, evaluate, and deploy AI solutions with Azure's comprehensive AI platform.",
    url: "https://azure.microsoft.com/en-us/products/ai-studio",
    category: "AI Platform",
    icon: Code,
    color: "from-purple-500 to-purple-600",
  },
  {
    title: "GitHub Copilot",
    description: "AI-powered code completion and programming assistant for developers.",
    url: "https://github.com/features/copilot",
    category: "Development Tool",
    icon: Code,
    color: "from-green-500 to-green-600",
  },
  {
    title: "Microsoft Student Hub",
    description: "Resources, benefits, and opportunities for students in technology.",
    url: "https://studenthub.microsoft.com",
    category: "Student Resources",
    icon: Users,
    color: "from-orange-500 to-orange-600",
  },
  {
    title: "Azure for Students",
    description: "Free Azure credits and services for students to build and deploy applications.",
    url: "https://azure.microsoft.com/en-us/free/students",
    category: "Cloud Platform",
    icon: Star,
    color: "from-cyan-500 to-cyan-600",
  },
  {
    title: "Microsoft Reactor",
    description: "Join workshops, meetups, and events in the Microsoft developer community.",
    url: "https://developer.microsoft.com/en-us/reactor",
    category: "Community",
    icon: Video,
    color: "from-pink-500 to-pink-600",
  },
];

const learningPaths = [
  {
    title: "AI & Machine Learning",
    description: "Master artificial intelligence and machine learning concepts",
    modules: ["Introduction to AI", "Machine Learning Fundamentals", "Deep Learning", "AI Ethics"],
    level: "Beginner to Advanced",
  },
  {
    title: "Cloud Development",
    description: "Build scalable applications using cloud technologies",
    modules: ["Azure Fundamentals", "Cloud Architecture", "Serverless Computing", "DevOps"],
    level: "Intermediate",
  },
  {
    title: "Web Development",
    description: "Create modern web applications with latest technologies",
    modules: ["Frontend Frameworks", "Backend APIs", "Database Design", "Deployment"],
    level: "Beginner",
  },
  {
    title: "Data Science",
    description: "Analyze and visualize data to derive meaningful insights",
    modules: ["Data Analysis", "Statistical Methods", "Data Visualization", "Big Data"],
    level: "Intermediate",
  },
];

export default function Resources() {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-hero py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-4xl text-center">
            <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-6xl">
              Learning <span className="gradient-text">Resources</span>
            </h1>
            <p className="mt-6 text-lg leading-8 text-foreground-muted max-w-2xl mx-auto">
              Access our comprehensive collection of resources to accelerate your learning and development journey.
            </p>
          </div>
        </div>
      </section>

      {/* Downloadable Resources */}
      <section className="py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center mb-16">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Downloadable Resources
            </h2>
            <p className="mt-6 text-lg leading-8 text-foreground-muted">
              Download official documents, reports, and guides from MSC MPSTME.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-2 max-w-6xl mx-auto">
            <AnimatePresence>
              {downloadableResources.map((resource, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 40, scale: 0.97 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 40, scale: 0.97 }}
                  transition={{ duration: 0.6, delay: index * 0.1, type: "spring" }}
                >
                  <motion.div whileHover={{ scale: 1.03, boxShadow: "0 8px 32px 0 rgba(59,130,246,0.10)" }}>
                    <Card className={`bg-gradient-card border-card-border card-hover ${resource.featured ? 'ring-2 ring-primary/20' : ''}`}>
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                              <resource.icon className="h-6 w-6 text-primary" />
                            </div>
                            <div>
                              <CardTitle className="text-lg text-foreground">{resource.title}</CardTitle>
                              <div className="flex items-center gap-2 mt-1">
                                <Badge variant="outline" className="text-xs">
                                  {resource.type}
                                </Badge>
                                <span className="text-xs text-foreground-muted">{resource.size}</span>
                                {resource.featured && (
                                  <Badge variant="outline" className="bg-primary/20 text-primary border-primary/30 text-xs">
                                    Featured
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-foreground-muted text-sm mb-4">{resource.description}</p>
                        <Button variant="outline" className="w-full" asChild>
                          <a href={resource.downloadUrl} download>
                            <Download className="mr-2 h-4 w-4" />
                            Download {resource.type}
                          </a>
                        </Button>
                      </CardContent>
                    </Card>
                  </motion.div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* External Resources */}
      <section className="py-16 sm:py-24 bg-background-secondary">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center mb-16">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              External Resources
            </h2>
            <p className="mt-6 text-lg leading-8 text-foreground-muted">
              Explore Microsoft's ecosystem of tools, platforms, and learning resources.
            </p>
          </div>

          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 max-w-6xl mx-auto">
            <AnimatePresence>
              {externalResources.map((resource, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 40, scale: 0.97 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 40, scale: 0.97 }}
                  transition={{ duration: 0.6, delay: index * 0.1, type: "spring" }}
                >
                  <motion.div whileHover={{ scale: 1.03, boxShadow: "0 8px 32px 0 rgba(59,130,246,0.10)" }}>
                    <Card className="bg-gradient-card border-card-border card-hover">
                      <CardHeader>
                        <div className="flex items-center gap-3">
                          <div className={`h-4 w-4 rounded-full bg-gradient-to-r ${resource.color}`} />
                          <Badge variant="outline" className="text-xs">
                            {resource.category}
                          </Badge>
                        </div>
                        <CardTitle className="text-lg text-foreground">{resource.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-foreground-muted text-sm mb-4">{resource.description}</p>
                        <Button variant="outline" className="w-full" asChild>
                          <a href={resource.url} target="_blank" rel="noopener noreferrer">
                            Visit Resource
                            <ExternalLink className="ml-2 h-4 w-4" />
                          </a>
                        </Button>
                      </CardContent>
                    </Card>
                  </motion.div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* Learning Paths */}
      <section className="py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center mb-16">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Learning Paths
            </h2>
            <p className="mt-6 text-lg leading-8 text-foreground-muted">
              Structured learning journeys to help you master different technology domains.
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-2 max-w-6xl mx-auto">
            <AnimatePresence>
              {learningPaths.map((path, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 40, scale: 0.97 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 40, scale: 0.97 }}
                  transition={{ duration: 0.6, delay: index * 0.1, type: "spring" }}
                >
                  <motion.div whileHover={{ scale: 1.03, boxShadow: "0 8px 32px 0 rgba(59,130,246,0.10)" }}>
                    <Card className="bg-gradient-card border-card-border card-hover">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-xl text-foreground">{path.title}</CardTitle>
                          <Badge variant="outline" className="text-xs">
                            {path.level}
                          </Badge>
                        </div>
                        <CardDescription className="text-foreground-muted">
                          {path.description}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="mb-4">
                          <h4 className="font-semibold text-foreground mb-3 text-sm">Learning Modules</h4>
                          <div className="grid grid-cols-2 gap-2">
                            {path.modules.map((module, idx) => (
                              <div key={idx} className="flex items-center gap-2">
                                <div className="h-2 w-2 rounded-full bg-primary" />
                                <span className="text-foreground-muted text-xs">{module}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                        <Button variant="outline" className="w-full" asChild>
                          <a href="https://learn.microsoft.com" target="_blank" rel="noopener noreferrer">
                            Start Learning
                            <ExternalLink className="ml-2 h-4 w-4" />
                          </a>
                        </Button>
                      </CardContent>
                    </Card>
                  </motion.div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 sm:py-24 bg-background-secondary">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Need More Resources?
            </h2>
            <p className="mt-6 text-lg leading-8 text-foreground-muted">
              Can't find what you're looking for? Reach out to us and we'll help you find the right resources.
            </p>
            <div className="mt-10 flex items-center justify-center gap-6">
              <Button variant="hero" size="lg" asChild>
                <a href="/contact">Contact Us</a>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <a href="/about">Learn More</a>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}