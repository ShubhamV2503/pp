import { ArrowRight, Calendar, Users, Zap, ExternalLink, ChevronRight, Trophy, Lightbulb, Code, Rocket } from "lucide-react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Layout from "@/components/layout/Layout";
import mscLogo from "@/assets/msc-logo.jpeg";

import bgImage from "@/assets/BG.jpg";

const featuredEvents = [
  {
    title: "Equinox 2.0",
    subtitle: "Generative AI Symposium",
    description: "Join us for the ultimate AI innovation event with workshops, competitions, and networking.",
    date: "Completed",
    participants: "150+ Expected",
    status: "Past Event",
    href: "/events",
  },
  {
    title: "Equinox 1.0",
    subtitle: "Tech Innovation Summit",
    description: "Our flagship event that brought together 350+ tech enthusiasts.",
    date: "Completed",
    participants: "100+ Attendees",
    status: "Past Event",
    href: "/events",
  },
];

const quickLinks = [
  {
    name: "Microsoft Learn",
    description: "Access official Microsoft learning resources",
    href: "https://learn.microsoft.com",
    icon: ExternalLink,
    external: true,
  },
  {
    name: "Azure AI Studio",
    description: "Build and deploy AI solutions",
    href: "https://azure.microsoft.com/en-us/products/ai-studio",
    icon: ExternalLink,
    external: true,
  },
  {
    name: "Committee Structure",
    description: "Meet our team and departments",
    href: "/committee",
    icon: Users,
    external: false,
  },
  {
    name: "Event Gallery",
    description: "Explore our past events and activities",
    href: "/gallery",
    icon: Calendar,
    external: false,
  },
];

const achievements = [
  {
    icon: Trophy,
    title: "Team Ideologist",
    description: "1st Place Winner - Equinox 2.0",
  },
  {
    icon: Zap,
    title: "95% Satisfaction",
    description: "Positive feedback from participants",
  },
  {
    icon: Users,
    title: "150+ Attendees",
    description: "Record participation in events",
  },
  {
    icon: Lightbulb,
    title: "Innovation Hub",
    description: "Fostering creativity and tech skills",
  },
];

const Index = () => {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-hero">
        <motion.div
          className="hero-glow"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
        >
          <div className="mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8">
            <motion.div
              className="mx-auto max-w-5xl text-center relative py-20 px-6 rounded-3xl overflow-hidden shadow-2xl"
              initial={{ opacity: 0, y: 60 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, type: "spring" }}
            >
              {/* Background Logo */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-0 opacity-40 select-none">
                <img
                  src={bgImage}
                  alt=""
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/40"></div>
              </div>

              <motion.h1
                className="relative z-10 text-4xl font-bold tracking-tight text-white sm:text-6xl lg:text-7xl pt-4"
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3, duration: 0.7, type: "spring" }}
              >
                Microsoft Student Club
                <span className="block gradient-text">MPSTME</span>
              </motion.h1>
              <motion.p
                className="relative z-10 mt-6 text-lg leading-8 text-foreground-muted sm:text-xl max-w-2xl mx-auto"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5, duration: 0.7 }}
              >
                Innovating Today, Empowering Tomorrow. Join a vibrant community of tech enthusiasts passionate about learning, building, and leading the future.
              </motion.p>
              <motion.div
                className="relative z-10 mt-10 flex flex-col sm:flex-row items-center justify-center gap-4"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.7, duration: 0.7 }}
              >
                <motion.div whileHover={{ scale: 1.06 }} whileTap={{ scale: 0.97 }}>
                  <Button variant="hero" size="xl" className="w-full sm:w-auto" asChild>
                    <Link to="/contact">
                      Join the Club
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </Link>
                  </Button>
                </motion.div>
                <motion.div whileHover={{ scale: 1.06 }} whileTap={{ scale: 0.97 }}>
                  <Button variant="outline" size="xl" className="w-full sm:w-auto" asChild>
                    <Link to="/committee">
                      Explore Departments
                      <ChevronRight className="ml-2 h-5 w-5" />
                    </Link>
                  </Button>
                </motion.div>
                <motion.div whileHover={{ scale: 1.06 }} whileTap={{ scale: 0.97 }}>
                  <Button variant="glass" size="xl" className="w-full sm:w-auto" asChild>
                    <Link to="/events">
                      See Events
                      <Calendar className="ml-2 h-5 w-5" />
                    </Link>
                  </Button>
                </motion.div>
              </motion.div>
            </motion.div>
          </div>
        </motion.div>
      </section>

      {/* About Snippet */}
      <section className="py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-4xl text-center">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              About MSC, MPSTME
            </h2>
            <p className="mt-6 text-lg leading-8 text-foreground-muted">
              The Microsoft Students Club at MPSTME is a student-driven community that brings together tech enthusiasts, innovators, and leaders. Established in 2024 through a collaboration between Microsoft and NMIMS, we bridge academic knowledge and industry practices.
            </p>
            <div className="mt-8">
              <Button variant="outline" size="lg" asChild>
                <Link to="/about">
                  Learn More About Us
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Events */}
      <section className="py-16 sm:py-24 bg-background-secondary">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Featured Events
            </h2>
            <p className="mt-6 text-lg leading-8 text-foreground-muted">
              Discover our signature events that shape the future of technology and innovation.
            </p>
          </div>
          <div className="mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-8 lg:mx-0 lg:max-w-none lg:grid-cols-2">
            <AnimatePresence>
              {featuredEvents.map((event, index) => (
                <motion.div
                  key={event.title}
                  initial={{ opacity: 0, y: 40, scale: 0.97 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 40, scale: 0.97 }}
                  transition={{ duration: 0.7, delay: index * 0.15, type: "spring" }}
                >
                  <motion.div whileHover={{ scale: 1.03, boxShadow: "0 8px 32px 0 rgba(59,130,246,0.10)" }}>
                    <Card className="card-hover bg-gradient-card border-card-border">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-xl text-foreground">{event.title}</CardTitle>
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${event.status === 'Upcoming'
                            ? 'bg-primary/20 text-primary'
                            : 'bg-muted text-muted-foreground'
                            }`}>
                            {event.status}
                          </span>
                        </div>
                        <CardDescription className="text-msc-blue font-medium">
                          {event.subtitle}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <p className="text-foreground-muted mb-4">{event.description}</p>
                        <div className="flex justify-between text-sm text-foreground-muted mb-4">
                          <span>{event.date}</span>
                          <span>{event.participants}</span>
                        </div>
                        <Button variant="outline" className="w-full" asChild>
                          <Link to={event.href}>
                            Learn More
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </Link>
                        </Button>
                      </CardContent>
                    </Card>
                  </motion.div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* Achievements */}
      <section className="py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Our Achievements
            </h2>
            <p className="mt-6 text-lg leading-8 text-foreground-muted">
              Celebrating the success and impact of our community initiatives.
            </p>
          </div>
          <div className="mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-8 sm:grid-cols-2 lg:mx-0 lg:max-w-none lg:grid-cols-4">
            <AnimatePresence>
              {achievements.map((achievement, index) => (
                <motion.div
                  key={achievement.title}
                  initial={{ opacity: 0, y: 40, scale: 0.97 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 40, scale: 0.97 }}
                  transition={{ duration: 0.6, delay: index * 0.1, type: "spring" }}
                  className="text-center"
                >
                  <motion.div whileHover={{ scale: 1.08, rotate: [0, 6, -6, 0] }} transition={{ duration: 0.5, type: "spring" }}>
                    <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                      <achievement.icon className="h-8 w-8 text-primary" />
                    </div>
                  </motion.div>
                  <h3 className="mt-6 text-lg font-semibold text-foreground">{achievement.title}</h3>
                  <p className="mt-2 text-sm text-foreground-muted">{achievement.description}</p>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* Quick Links */}
      <section className="py-16 sm:py-24 bg-background-secondary">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Quick Links
            </h2>
            <p className="mt-6 text-lg leading-8 text-foreground-muted">
              Access essential resources and explore our community.
            </p>
          </div>
          <div className="mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-8 sm:grid-cols-2 lg:mx-0 lg:max-w-none lg:grid-cols-2">
            {quickLinks.map((link, index) => (
              <Card key={link.name} className="card-hover bg-gradient-card border-card-border animate-slide-in-right" style={{ animationDelay: `${index * 0.1}s` }}>
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                      <link.icon className="h-5 w-5 text-primary" />
                    </div>
                    <CardTitle className="text-lg text-foreground">{link.name}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-foreground-muted mb-4">{link.description}</p>
                  {link.external ? (
                    <Button variant="outline" className="w-full" asChild>
                      <a href={link.href} target="_blank" rel="noopener noreferrer">
                        Visit Resource
                        <ExternalLink className="ml-2 h-4 w-4" />
                      </a>
                    </Button>
                  ) : (
                    <Button variant="outline" className="w-full" asChild>
                      <Link to={link.href}>
                        Explore
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Index;
