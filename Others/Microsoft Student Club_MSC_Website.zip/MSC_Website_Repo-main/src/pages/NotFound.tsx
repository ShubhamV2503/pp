import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import { motion } from "framer-motion";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-100">
      <motion.div
        className="text-center"
        initial={{ opacity: 0, y: 60 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, type: "spring" }}
      >
        <motion.h1
          className="mb-4 text-4xl font-bold"
          initial={{ scale: 0.8 }}
          animate={{ scale: [1.2, 0.95, 1.1, 1] }}
          transition={{ duration: 1.2, type: "spring", bounce: 0.6 }}
        >
          404
        </motion.h1>
        <motion.p
          className="mb-4 text-xl text-gray-600"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.7 }}
        >
          Oops! Page not found
        </motion.p>
        <motion.a
          href="/"
          className="text-blue-500 underline hover:text-blue-700"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7, duration: 0.6 }}
        >
          Return to Home
        </motion.a>
      </motion.div>
    </div>
  );
};

export default NotFound;
