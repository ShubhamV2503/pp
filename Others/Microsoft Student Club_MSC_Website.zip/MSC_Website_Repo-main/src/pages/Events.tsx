import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Calendar, Users, Zap, Clock, MapPin, Star, Plus, Trash, Filter, X, Award } from "lucide-react";
import Layout from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  AlertDialog,
  AlertDialogTrigger,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogCancel,
  AlertDialogAction,
} from "@/components/ui/alert-dialog";

/* ---------------- UPCOMING EVENTS ---------------- */

const upcomingEvents = [
  {
    title: "AI Hackathon",
    description: "Build AI-powered solutions in a competitive environment.",
    date: "12th March 2026",
    location: "MPSTME Campus",
    type: "Team",
  },
  {
    title: "Tech Quiz",
    description: "Test your technical knowledge across domains.",
    date: "15th March 2026",
    location: "Auditorium",
    type: "Solo",
  },
];

/* ---------------- COMPLETED EVENTS ---------------- */

const completedEvents = [
  {
    title: "Equinox 2.0",
    subtitle: "Generative AI Symposium",
    description:
      "The ultimate AI innovation event featuring workshops, competitions, networking sessions, and expert talks.",
    date: "22nd September 2025",
    location: "MPSTME Campus",
    participants: "150+",
    satisfaction: "96%",
    image: "/src/assets/events/equinox2.jpg", // Add your image path here
    features: [
      "Hands-on AI Workshops",
      "Competition Tracks",
      "Industry Expert Sessions",
      "Networking Opportunities",
      "Innovation Showcase",
    ],
    winners: [
      { position: "🥇", team: "Team Ideologist" },
      { position: "🥈", team: "Team PowerPuff Boys" },
      { position: "🥉", team: "Team Decepticons" },
    ],
  },
];

/* ---------------- GALLERY DATA ---------------- */

const galleryImages = [
  {
    id: 1,
    title: "Equinox 1.0 Opening Ceremony",
    category: "Events",
    event: "Equinox 1.0",
    description: "The grand opening of our flagship tech innovation summit",
    date: "2024",
    participants: "350+",
    src: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&h=600&fit=crop",
  },
  {
    id: 2,
    title: "Workshop Session - AI Fundamentals",
    category: "Workshops",
    event: "AI Workshop Series",
    description: "Students learning about artificial intelligence and machine learning",
    date: "2024",
    participants: "50+",
    src: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=800&h=600&fit=crop",
  },
  {
    id: 3,
    title: "Team Collaboration",
    category: "Hackathons",
    event: "MSC Hackathon",
    description: "Teams working together to solve real-world problems",
    date: "2024",
    participants: "80+",
    src: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&h=600&fit=crop",
  },
  {
    id: 4,
    title: "Guest Speaker Session",
    category: "Talks",
    event: "Industry Insights",
    description: "Industry professionals sharing their expertise with students",
    date: "2024",
    participants: "100+",
    src: "https://images.unsplash.com/photo-1475721027785-f74eccf877e2?w=800&h=600&fit=crop",
  },
  {
    id: 5,
    title: "Networking Session",
    category: "Events",
    event: "MSC Meetup",
    description: "Students and professionals networking and sharing ideas",
    date: "2024",
    participants: "120+",
    src: "https://images.unsplash.com/photo-1515187029135-18ee286d815b?w=800&h=600&fit=crop",
  },
  {
    id: 6,
    title: "Award Ceremony",
    category: "Events",
    event: "Equinox 1.0",
    description: "Celebrating the winners of our competition tracks",
    date: "2024",
    participants: "350+",
    src: "https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?w=800&h=600&fit=crop",
  },
  {
    id: 7,
    title: "Coding Workshop",
    category: "Workshops",
    event: "Programming Bootcamp",
    description: "Hands-on coding session with latest technologies",
    date: "2024",
    participants: "40+",
    src: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800&h=600&fit=crop",
  },
  {
    id: 8,
    title: "Team Building Activity",
    category: "Community",
    event: "MSC Social",
    description: "Fun activities to strengthen our community bonds",
    date: "2024",
    participants: "60+",
    src: "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=800&h=600&fit=crop",
  },
];

const categories = ["All", "Events", "Workshops", "Hackathons", "Talks", "Community"];

export default function Events() {
  const [teamMembers, setTeamMembers] = useState<string[]>([""]);
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedImage, setSelectedImage] = useState<typeof galleryImages[0] | null>(null);
  const MAX_MEMBERS = 6;

  const addMember = () => {
    if (teamMembers.length < MAX_MEMBERS) {
      setTeamMembers([...teamMembers, ""]);
    }
  };

  const removeMember = (index: number) => {
    setTeamMembers(teamMembers.filter((_, i) => i !== index));
  };

  const updateMember = (index: number, value: string) => {
    const updated = [...teamMembers];
    updated[index] = value;
    setTeamMembers(updated);
  };

  // Filter events by search
  const filteredUpcoming = upcomingEvents;
  const filteredCompleted = completedEvents.filter(e =>
    e.title.toLowerCase().includes(search.toLowerCase())
  );

  // Filter images by category
  const filteredImages = selectedCategory === "All"
    ? galleryImages
    : galleryImages.filter(img => img.category === selectedCategory);

  return (
    <Layout>
      {/* HERO */}
      <section className="bg-gradient-hero py-24 text-center">
        <h1 className="text-4xl font-bold sm:text-6xl">
          Events & <span className="gradient-text">Initiatives</span>
        </h1>
        <p className="mt-6 max-w-2xl mx-auto text-lg text-foreground-muted">
          Register for upcoming events, explore our completed milestones, and view our event gallery.
        </p>
      </section>

      {/* ================= SEARCH & UPCOMING EVENTS ================= */}
      <section className="py-24">
        <div className="mx-auto max-w-7xl px-6">
          <h2 className="text-center text-3xl font-bold mb-16">
            Upcoming Events
          </h2>



          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence>
              {filteredUpcoming.map((event, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 40, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 40, scale: 0.95 }}
                  transition={{ duration: 0.6, delay: index * 0.12, type: "spring" }}
                >
                  <motion.div whileHover={{ scale: 1.03, boxShadow: "0 8px 32px 0 rgba(59,130,246,0.12)" }}>
                    <Card className="bg-gradient-card border-card-border card-hover">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-lg">{event.title}</CardTitle>
                          <Badge variant="outline">{event.type}</Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-foreground-muted mb-4">
                          {event.description}
                        </p>
                        <div className="space-y-2 mb-6">
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-primary" />
                            {event.date}
                          </div>
                          <div className="flex items-center gap-2">
                            <MapPin className="h-4 w-4 text-primary" />
                            {event.location}
                          </div>
                        </div>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="hero" size="sm" className="w-full">
                              Register
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>
                                Register for {event.title}
                              </AlertDialogTitle>
                              <AlertDialogDescription>
                                {event.type === "Team"
                                  ? "Team leader should fill in team details."
                                  : "Fill in your details to participate."}
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            {/* FORM */}
                            <div className="space-y-4 py-4">
                              <input
                                className="w-full rounded-md border border-card-border bg-background px-3 py-2 text-sm text-foreground"
                                placeholder="Full Name"
                              />
                              <input
                                className="w-full rounded-md border border-card-border bg-background px-3 py-2 text-sm text-foreground"
                                placeholder="College Email"
                              />
                              {event.type === "Team" && (
                                <>
                                  <input
                                    className="w-full rounded-md border border-card-border bg-background px-3 py-2 text-sm text-foreground"
                                    placeholder="Team Name"
                                  />
                                  <div className="space-y-3">
                                    <p className="text-sm font-medium">
                                      Team Members (Leader is Member 1)
                                    </p>
                                    {teamMembers.map((member, i) => (
                                      <div key={i} className="flex gap-2">
                                        <input
                                          className="flex-1 rounded-md border border-card-border bg-background px-3 py-2 text-sm text-foreground"
                                          placeholder={`Member ${i + 1} Name`}
                                          value={member}
                                          onChange={(e) => updateMember(i, e.target.value)}
                                        />
                                        {i > 0 && (
                                          <button
                                            onClick={() => removeMember(i)}
                                            className="text-red-500"
                                          >
                                            <Trash size={16} />
                                          </button>
                                        )}
                                      </div>
                                    ))}
                                    {teamMembers.length < MAX_MEMBERS && (
                                      <button
                                        onClick={addMember}
                                        className="flex items-center gap-1 text-sm text-primary"
                                      >
                                        <Plus size={16} />
                                        Add Member
                                      </button>
                                    )}
                                  </div>
                                </>
                              )}
                            </div>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction>
                                Submit Registration
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </CardContent>
                    </Card>
                  </motion.div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* ================= COMPLETED EVENTS ================= */}
      <section className="py-24 bg-background-secondary">
        <div className="mx-auto max-w-7xl px-6">
          <h2 className="text-center text-3xl font-bold mb-16">
            Completed Events
          </h2>

          {/* Search Box with Animation */}
          <motion.div
            className="flex justify-center mb-10"
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, type: "spring" }}
          >
            <motion.input
              type="text"
              placeholder="Search completed events..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full max-w-md px-4 py-2 border border-card-border rounded-lg bg-background-tertiary text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              whileFocus={{ scale: 1.03, boxShadow: "0 0 0 2px #3b82f6" }}
              whileHover={{ scale: 1.01 }}
            />
          </motion.div>

          <AnimatePresence>
            {filteredCompleted.map((event, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 60, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 60, scale: 0.97 }}
                transition={{ duration: 0.7, delay: index * 0.15, type: "spring" }}
                className="mb-12"
              >
                <motion.div whileHover={{ scale: 1.02, boxShadow: "0 8px 32px 0 rgba(34,197,94,0.10)" }}>
                  <Card className="bg-gradient-card border-card-border card-hover mx-auto max-w-4xl">
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="text-2xl">{event.title}</CardTitle>
                          <CardDescription className="text-primary font-semibold">
                            {event.subtitle}
                          </CardDescription>
                        </div>
                        <Badge className="bg-green-500/20 text-green-400">
                          Completed
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-4">
                      {/* Event Image */}
                      {event.image && (
                        <motion.img
                          src={event.image}
                          alt={event.title + " event"}
                          className="w-full h-64 object-cover rounded-lg mb-4 border border-card-border"
                          initial={{ scale: 0.95, opacity: 0 }}
                          whileInView={{ scale: 1, opacity: 1 }}
                          transition={{ duration: 0.7, delay: 0.2 + index * 0.1, type: "spring" }}
                        />
                      )}
                      <p className="text-foreground-muted mb-4">{event.description}</p>
                      <div className="grid md:grid-cols-4 gap-3 mb-6">
                        <div className="flex items-center gap-2">
                          <Calendar className="h-5 w-5 text-primary" />
                          <span className="text-sm">{event.date}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <MapPin className="h-5 w-5 text-primary" />
                          <span className="text-sm">{event.location}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Users className="h-5 w-5 text-primary" />
                          <span className="text-sm">{event.participants} Attendees</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Star className="h-5 w-5 text-primary" />
                          <span className="text-sm">{event.satisfaction} Satisfaction</span>
                        </div>
                      </div>
                      {/* Winners */}
                      {event.winners && (
                        <div className="mb-6">
                          <h4 className="font-semibold mb-2">Winners</h4>
                          <ul className="space-y-1">
                            {event.winners.map((winner, i) => (
                              <li key={i} className="flex items-center gap-2 text-base">
                                <span>{winner.position}</span>
                                <span className="font-medium">{winner.team}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                      <div>
                        <h4 className="font-semibold mb-2">Event Highlights</h4>
                        <div className="grid md:grid-cols-2 gap-2">
                          {event.features.map((f, i) => (
                            <div key={i} className="flex items-center gap-2">
                              <Zap className="h-4 w-4 text-primary" />
                              <span className="text-sm text-foreground-muted">{f}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </section>

      {/* ================= GALLERY SECTION ================= */}

      {/* Filter Section */}
      <section className="py-8 border-t border-b border-card-border bg-background-secondary/50">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="flex items-center justify-center">
            <div className="flex items-center gap-2 overflow-x-auto pb-2">
              <Filter className="h-5 w-5 text-foreground-muted flex-shrink-0" />
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "hero" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className="whitespace-nowrap"
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center mb-16">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Event Gallery
            </h2>
            <p className="mt-6 text-lg leading-8 text-foreground-muted">
              Explore highlights from our events, workshops, and community activities.
            </p>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            <AnimatePresence>
              {filteredImages.map((image, index) => (
                <motion.div
                  key={image.id}
                  initial={{ opacity: 0, y: 40, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 40, scale: 0.95 }}
                  transition={{ duration: 0.6, delay: index * 0.08, type: "spring" }}
                >
                  <motion.div
                    whileHover={{ scale: 1.04, boxShadow: "0 8px 32px 0 rgba(59,130,246,0.10)" }}
                    onClick={() => setSelectedImage(image)}
                  >
                    <Card className="bg-gradient-card border-card-border card-hover cursor-pointer group overflow-hidden">
                      <div className="relative overflow-hidden">
                        <motion.img
                          src={image.src}
                          alt={image.title}
                          className="w-full h-48 object-cover group-hover:scale-110"
                          initial={{ scale: 0.98, opacity: 0 }}
                          whileInView={{ scale: 1, opacity: 1 }}
                          transition={{ duration: 0.7, delay: 0.1 + index * 0.05, type: "spring" }}
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                        <div className="absolute top-3 left-3">
                          <Badge variant="outline" className="bg-black/50 text-white border-white/20">
                            {image.category}
                          </Badge>
                        </div>
                        <div className="absolute bottom-3 left-3 right-3">
                          <h3 className="text-white font-semibold text-sm line-clamp-2">{image.title}</h3>
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between text-xs text-foreground-muted">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            <span>{image.date}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Users className="h-3 w-3" />
                            <span>{image.participants}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          {filteredImages.length === 0 && (
            <div className="text-center py-16">
              <p className="text-foreground-muted text-lg">No images found for the selected category.</p>
            </div>
          )}
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 sm:py-24 bg-background-secondary">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center mb-16">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Our Impact in Numbers
            </h2>
            <p className="mt-6 text-lg leading-8 text-foreground-muted">
              Celebrating the milestones and achievements of our community.
            </p>
          </div>

          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            <div className="text-center animate-fade-in">
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 mb-4">
                <Calendar className="h-8 w-8 text-primary" />
              </div>
              <div className="text-3xl font-bold text-foreground">25+</div>
              <div className="text-foreground-muted">Events Organized</div>
            </div>
            <div className="text-center animate-fade-in" style={{ animationDelay: "0.1s" }}>
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 mb-4">
                <Users className="h-8 w-8 text-primary" />
              </div>
              <div className="text-3xl font-bold text-foreground">500+</div>
              <div className="text-foreground-muted">Participants Reached</div>
            </div>
            <div className="text-center animate-fade-in" style={{ animationDelay: "0.2s" }}>
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 mb-4">
                <Award className="h-8 w-8 text-primary" />
              </div>
              <div className="text-3xl font-bold text-foreground">15+</div>
              <div className="text-foreground-muted">Awards Given</div>
            </div>
            <div className="text-center animate-fade-in" style={{ animationDelay: "0.3s" }}>
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 mb-4">
                <Zap className="h-8 w-8 text-primary" />
              </div>
              <div className="text-3xl font-bold text-foreground">95%</div>
              <div className="text-foreground-muted">Satisfaction Rate</div>
            </div>
          </div>
        </div>
      </section>

      {/* Image Modal */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="relative max-w-4xl max-h-[90vh] overflow-auto"
              initial={{ scale: 0.95, y: 40, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.95, y: 40, opacity: 0 }}
              transition={{ duration: 0.4, type: "spring" }}
            >
              <Button
                variant="outline"
                size="icon"
                className="absolute top-4 right-4 z-10 bg-black/50 border-white/20 text-white hover:bg-black/70"
                onClick={() => setSelectedImage(null)}
              >
                <X className="h-4 w-4" />
              </Button>
              <Card className="bg-gradient-card border-card-border">
                <div className="relative">
                  <motion.img
                    src={selectedImage.src}
                    alt={selectedImage.title}
                    className="w-full max-h-[60vh] object-cover"
                    initial={{ scale: 0.98, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0.98, opacity: 0 }}
                    transition={{ duration: 0.5, type: "spring" }}
                  />
                  <div className="absolute top-4 left-4">
                    <Badge variant="outline" className="bg-black/50 text-white border-white/20">
                      {selectedImage.category}
                    </Badge>
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-2xl font-bold text-foreground mb-2">{selectedImage.title}</h3>
                  <p className="text-foreground-muted mb-4">{selectedImage.description}</p>
                  <div className="grid gap-4 sm:grid-cols-3">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-primary" />
                      <span className="text-foreground-muted text-sm">{selectedImage.date}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-primary" />
                      <span className="text-foreground-muted text-sm">{selectedImage.participants} Participants</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Award className="h-4 w-4 text-primary" />
                      <span className="text-foreground-muted text-sm">{selectedImage.event}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </Layout>
  );
}
