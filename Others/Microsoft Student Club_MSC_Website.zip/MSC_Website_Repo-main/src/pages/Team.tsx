import { Crown, Star, Users, Award, Mail, Linkedin, Github, ChevronDown, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import Layout from "@/components/layout/Layout";
import { motion, AnimatePresence } from "framer-motion";
import {
  AlertDialog,
  AlertDialogTrigger,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogCancel,
  AlertDialogAction,
} from "@/components/ui/alert-dialog";
import { useState } from "react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

const supercoreTeam = [
  {
    name: "Preet Shah",
    position: "President",
    description: "Leading MSC MPSTME's vision and strategic direction with a passion for innovation and community building.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face",
    email: "president@msc-mpstme.com",
    linkedin: "#",
    github: "#",
    achievements: ["Founded MSC MPSTME", "Led Equinox 1.0", "350+ Event Participants"],
    icon: Crown,
  },
  {
    name: "To Be Announced",
    position: "Vice President",
    description: "Supporting club operations and member engagement while driving innovative initiatives.",
    image: "https://images.unsplash.com/photo-1494790108755-2616b612b77c?w=400&h=400&fit=crop&crop=face",
    email: "vp@msc-mpstme.com",
    linkedin: "#",
    github: "#",
    achievements: ["Position Open", "Join Our Team", "Leadership Opportunity"],
    icon: Star,
  },
  {
    name: "To Be Announced",
    position: "Secretary",
    description: "Managing communications, documentation, and ensuring smooth organizational operations.",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
    email: "secretary@msc-mpstme.com",
    linkedin: "#",
    github: "#",
    achievements: ["Position Open", "Communication Skills", "Organizational Excellence"],
    icon: Users,
  },
  {
    name: "To Be Announced",
    position: "Joint Secretary",
    description: "Assisting in administrative functions and supporting all club activities and initiatives.",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=face",
    email: "jointsec@msc-mpstme.com",
    linkedin: "#",
    github: "#",
    achievements: ["Position Open", "Administrative Support", "Team Collaboration"],
    icon: Users,
  },
];

const departments = [
  {
    name: "Research & Development",
    description: "Driving innovation through cutting-edge research and technology exploration.",
    heads: ["Head - TBA"],
    subheads: ["Subhead - TBA"],
    executives: ["Executive positions open"],
    color: "from-blue-500 to-blue-600",
  },
  {
    name: "Marketing",
    description: "Building brand awareness and promoting MSC initiatives across the campus.",
    heads: ["Head - TBA"],
    subheads: ["Subhead - TBA"],
    executives: ["Executive positions open"],
    color: "from-green-500 to-green-600",
  },
  {
    name: "Public Relations",
    description: "Managing external communications and building industry connections.",
    heads: ["Head - TBA"],
    subheads: ["Subhead - TBA"],
    executives: ["Executive positions open"],
    color: "from-purple-500 to-purple-600",
  },
  {
    name: "Operations",
    description: "Ensuring smooth execution of events and day-to-day club activities.",
    heads: ["Head - TBA"],
    subheads: ["Subhead - TBA"],
    executives: ["Executive positions open"],
    color: "from-orange-500 to-orange-600",
  },
  {
    name: "Digital Creative",
    description: "Creating visual content and managing digital assets for the club.",
    heads: ["Head - TBA"],
    subheads: ["Subhead - TBA"],
    executives: ["Executive positions open"],
    color: "from-pink-500 to-pink-600",
  },
  {
    name: "SMCW (Social Media & Content Writing)",
    description: "Managing social media presence and creating engaging content.",
    heads: ["Head - TBA"],
    subheads: ["Subhead - TBA"],
    executives: ["Executive positions open"],
    color: "from-cyan-500 to-cyan-600",
  },
  {
    name: "I&C (Informals & Creatives)",
    description: "Organizing informal events and creative activities for community building.",
    heads: ["Head - TBA"],
    subheads: ["Subhead - TBA"],
    executives: ["Executive positions open"],
    color: "from-indigo-500 to-indigo-600",
  },
];

const facultyMentor = {
  name: "Dr. Dhirendra Mishra",
  position: "Faculty Mentor",
  description: "Guiding and mentoring the Microsoft Student Club with extensive expertise in technology and education. Providing strategic direction and academic support to help students achieve their potential.",
  image: "https://images.unsplash.com/photo-1552058544-f2b08422138a?w=400&h=400&fit=crop&crop=face",
  department: "MPSTME, NMIMS University",
  expertise: ["Technology Education", "Research Supervision", "Student Mentorship", "Academic Leadership"],
};

export default function Team() {
  const [openDepartments, setOpenDepartments] = useState<string[]>([]);

  const toggleDepartment = (departmentName: string) => {
    setOpenDepartments(prev =>
      prev.includes(departmentName)
        ? prev.filter(name => name !== departmentName)
        : [...prev, departmentName]
    );
  };

  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-hero py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-4xl text-center">
            <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-6xl">
              Meet Our <span className="gradient-text">Team</span>
            </h1>
            <p className="mt-6 text-lg leading-8 text-foreground-muted max-w-2xl mx-auto">
              Get to know the passionate individuals driving innovation and building the future of tech at MSC MPSTME.
            </p>
          </div>
        </div>
      </section>

      {/* Faculty Mentor */}
      <section className="py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center mb-16">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Faculty Mentor
            </h2>
            <p className="mt-6 text-lg leading-8 text-foreground-muted">
              Our guiding mentor providing wisdom and direction to our community.
            </p>
          </div>

          <Card className="bg-gradient-card border-card-border card-hover mx-auto max-w-4xl">
            <CardContent className="p-8">
              <div className="grid gap-8 md:grid-cols-2 items-center">
                <div className="text-center md:text-left">
                  <img
                    src={facultyMentor.image}
                    alt={facultyMentor.name}
                    className="w-48 h-48 rounded-full object-cover mx-auto md:mx-0 mb-6 shadow-glow"
                  />
                </div>
                <div>
                  <h3 className="text-3xl font-bold text-foreground mb-2">{facultyMentor.name}</h3>
                  <p className="text-xl text-primary font-semibold mb-2">{facultyMentor.position}</p>
                  <p className="text-foreground-muted text-sm mb-4">{facultyMentor.department}</p>
                  <p className="text-foreground-muted leading-7 mb-6">{facultyMentor.description}</p>
                  <div>
                    <h4 className="font-semibold text-foreground mb-3">Areas of Expertise</h4>
                    <div className="flex flex-wrap gap-2">
                      {facultyMentor.expertise.map((skill, index) => (
                        <Badge key={index} variant="outline" className="bg-primary/10 text-primary border-primary/30">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Supercore Team Hierarchy */}
      <section className="py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Supercore Team Hierarchy
            </h2>
            <p className="mt-6 text-lg leading-8 text-foreground-muted">
              Visualize the leadership structure and click on each member for more info.
            </p>
          </div>
          {/* Hierarchy Tree */}
          <div className="flex flex-col items-center mt-16">
            {/* President at top with animation */}
            <motion.div
              initial={{ opacity: 0, y: -40, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.7, type: "spring" }}
              className="flex flex-col items-center"
            >
              <motion.div whileHover={{ scale: 1.04, boxShadow: "0 8px 32px 0 rgba(59,130,246,0.12)" }}>
                <Card className="bg-gradient-card border-card-border card-hover text-center w-56">
                  <CardHeader>
                    <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                      <Crown className="h-8 w-8 text-primary" />
                    </div>
                    <CardTitle className="text-xl text-foreground">President</CardTitle>
                    <CardDescription className="text-primary font-semibold">{supercoreTeam[0].name}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-foreground-muted text-sm leading-6">Leading the vision and strategic direction of MSC MPSTME.</p>
                  </CardContent>
                </Card>
              </motion.div>
              {/* Down arrow */}
              <motion.div initial={{ opacity: 0, scaleY: 0.5 }} animate={{ opacity: 1, scaleY: 1 }} transition={{ delay: 0.3, duration: 0.5 }} className="h-8 w-1 bg-primary/30 my-2" />
              {/* Next row: VP, Secretary, Joint Secretary */}
              <div className="flex gap-8 flex-wrap justify-center">
                <AnimatePresence>
                  {supercoreTeam.slice(1).map((member, index) => (
                    <motion.div
                      key={member.position}
                      initial={{ opacity: 0, y: 40, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 40, scale: 0.95 }}
                      transition={{ duration: 0.6, delay: 0.2 + index * 0.12, type: "spring" }}
                    >
                      <motion.div whileHover={{ scale: 1.04, boxShadow: "0 8px 32px 0 rgba(59,130,246,0.10)" }}>
                        <Card className="bg-gradient-card border-card-border card-hover text-center w-56">
                          <CardHeader>
                            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                              <member.icon className="h-8 w-8 text-primary" />
                            </div>
                            <CardTitle className="text-xl text-foreground">{member.position}</CardTitle>
                            <CardDescription className="text-primary font-semibold">{member.name}</CardDescription>
                          </CardHeader>
                          <CardContent>
                            <p className="text-foreground-muted text-sm leading-6 line-clamp-2 md:line-clamp-none">
                              {member.description}
                            </p>
                          </CardContent>
                        </Card>
                      </motion.div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Supercore Team */}
      <section className="py-16 sm:py-24 bg-background-secondary">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center mb-16">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Supercore Team
            </h2>
            <p className="mt-6 text-lg leading-8 text-foreground-muted">
              The leadership team guiding MSC MPSTME's vision and strategic direction.
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-2 max-w-6xl mx-auto">
            <AnimatePresence>
              {supercoreTeam.map((member, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 40, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 40, scale: 0.95 }}
                  transition={{ duration: 0.6, delay: index * 0.12, type: "spring" }}
                >
                  <motion.div whileHover={{ scale: 1.04, boxShadow: "0 8px 32px 0 rgba(59,130,246,0.10)" }}>
                    <Card className="bg-gradient-card border-card-border card-hover">
                      <CardHeader className="text-center">
                        <div className="relative mx-auto mb-4">
                          <img
                            src={member.image}
                            alt={member.name}
                            className="w-24 h-24 rounded-full object-cover mx-auto shadow-blue"
                          />
                          <div className="absolute -bottom-2 -right-2 flex h-8 w-8 items-center justify-center rounded-full bg-primary">
                            <member.icon className="h-4 w-4 text-white" />
                          </div>
                        </div>
                        <CardTitle className="text-xl text-foreground">{member.name}</CardTitle>
                        <CardDescription className="text-primary font-semibold text-lg">
                          {member.position}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <p className="text-foreground-muted text-sm leading-6 mb-6 text-center">{member.description}</p>
                        <div className="mb-6">
                          <h4 className="font-semibold text-foreground mb-3 text-sm">Key Achievements</h4>
                          <div className="space-y-2">
                            {member.achievements.map((achievement, idx) => (
                              <div key={idx} className="flex items-center gap-2">
                                <Award className="h-3 w-3 text-primary" />
                                <span className="text-foreground-muted text-xs">{achievement}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                        <div className="flex justify-center gap-3">
                          <Button variant="outline" size="sm" asChild>
                            <a href={`mailto:${member.email}`}>
                              <Mail className="h-4 w-4" />
                            </a>
                          </Button>
                          <Button variant="outline" size="sm" asChild>
                            <a href={member.linkedin} target="_blank" rel="noopener noreferrer">
                              <Linkedin className="h-4 w-4" />
                            </a>
                          </Button>
                          <Button variant="outline" size="sm" asChild>
                            <a href={member.github} target="_blank" rel="noopener noreferrer">
                              <Github className="h-4 w-4" />
                            </a>
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* Departments Section */}
      <section className="py-16 sm:py-24 bg-background-secondary">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Departments
            </h2>
            <p className="mt-6 text-lg leading-8 text-foreground-muted">
              Explore our specialized departments, each contributing unique expertise to our community.
            </p>
          </div>
          <div className="mx-auto mt-16 max-w-7xl grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            <AnimatePresence>
              {departments.map((department, index) => (
                <motion.div
                  key={department.name}
                  initial={{ opacity: 0, y: 40, scale: 0.97 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 40, scale: 0.97 }}
                  transition={{ duration: 0.6, delay: index * 0.1, type: "spring" }}
                  className="h-full"
                >
                  <motion.div whileHover={{ scale: 1.02, boxShadow: "0 8px 32px 0 rgba(59,130,246,0.10)" }} className="h-full">
                    <Card className="bg-gradient-card border-card-border card-hover h-full flex flex-col">
                      <Collapsible
                        open={openDepartments.includes(department.name)}
                        onOpenChange={() => toggleDepartment(department.name)}
                        className="flex flex-col h-full"
                      >
                        <CollapsibleTrigger asChild>
                          <CardHeader className="cursor-pointer hover:bg-secondary/10 transition-colors flex-grow">
                            <div className="flex flex-col gap-4">
                              <div className="flex items-center justify-between w-full">
                                <div className={`h-4 w-4 rounded-full bg-gradient-to-r ${department.color}`} />
                                {openDepartments.includes(department.name) ? (
                                  <ChevronDown className="h-5 w-5 text-foreground-muted" />
                                ) : (
                                  <ChevronRight className="h-5 w-5 text-foreground-muted" />
                                )}
                              </div>
                              <div>
                                <CardTitle className="text-xl text-foreground mb-2">{department.name}</CardTitle>
                                <CardDescription className="text-foreground-muted line-clamp-3">
                                  {department.description}
                                </CardDescription>
                              </div>
                            </div>
                          </CardHeader>
                        </CollapsibleTrigger>
                        <AnimatePresence initial={false}>
                          {openDepartments.includes(department.name) && (
                            <CollapsibleContent asChild forceMount>
                              <motion.div
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: "auto" }}
                                exit={{ opacity: 0, height: 0 }}
                                transition={{ duration: 0.5, type: "spring" }}
                              >
                                <CardContent className="pt-0 mt-auto">
                                  <div className="space-y-6">
                                    <div>
                                      <h4 className="font-semibold text-foreground mb-2 text-sm uppercase tracking-wider">Core Team</h4>
                                      <div className="space-y-1">
                                        {department.heads.map((head, idx) => (
                                          <p key={idx} className="text-sm text-foreground-muted font-medium">{head}</p>
                                        ))}
                                        {department.subheads.map((subhead, idx) => (
                                          <p key={idx} className="text-sm text-foreground-muted">{subhead}</p>
                                        ))}
                                      </div>
                                    </div>
                                    <div>
                                      <h4 className="font-semibold text-foreground mb-2 text-sm uppercase tracking-wider">Executives</h4>
                                      <div className="space-y-1">
                                        {department.executives.map((executive, idx) => (
                                          <p key={idx} className="text-sm text-foreground-muted">{executive}</p>
                                        ))}
                                      </div>
                                    </div>
                                    <div className="pt-4 border-t border-border/50">
                                      <AlertDialog>
                                        <AlertDialogTrigger asChild>
                                          <Button variant="outline" size="sm" className="w-full">
                                            Join Department
                                          </Button>
                                        </AlertDialogTrigger>
                                        <AlertDialogContent>
                                          <AlertDialogHeader>
                                            <AlertDialogTitle>
                                              Apply for {department.name}
                                            </AlertDialogTitle>
                                            <AlertDialogDescription>
                                              Fill in your details and upload your resume for this role.
                                            </AlertDialogDescription>
                                          </AlertDialogHeader>
                                          <div className="space-y-4 py-4">
                                            <input
                                              className="w-full rounded-md border border-card-border bg-background px-3 py-2 text-sm text-foreground placeholder:text-foreground-muted"
                                              placeholder="Full Name"
                                            />
                                            <input
                                              className="w-full rounded-md border border-card-border bg-background px-3 py-2 text-sm text-foreground placeholder:text-foreground-muted"
                                              placeholder="College Email"
                                            />
                                            <input
                                              className="w-full rounded-md border border-card-border bg-background px-3 py-2 text-sm text-foreground placeholder:text-foreground-muted"
                                              placeholder="Year / Branch"
                                            />
                                            <input
                                              className="w-full rounded-md border border-card-border bg-background px-3 py-2 text-sm text-foreground placeholder:text-foreground-muted"
                                              placeholder="Position Applying For"
                                            />
                                            <input
                                              type="file"
                                              accept=".pdf,.doc,.docx"
                                              className="w-full text-sm text-foreground"
                                            />
                                          </div>
                                          <AlertDialogFooter>
                                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                                            <AlertDialogAction>
                                              Submit Application
                                            </AlertDialogAction>
                                          </AlertDialogFooter>
                                        </AlertDialogContent>
                                      </AlertDialog>
                                    </div>
                                  </div>
                                </CardContent>
                              </motion.div>
                            </CollapsibleContent>
                          )}
                        </AnimatePresence>
                      </Collapsible>
                    </Card>
                  </motion.div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* Join Team CTA */}
      <section className="py-16 sm:py-24 bg-background-secondary">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Ready to Join Our Team?
            </h2>
            <p className="mt-6 text-lg leading-8 text-foreground-muted">
              We're always looking for passionate individuals to join our mission of innovation and community building.
            </p>
            <div className="mt-10 flex items-center justify-center gap-6">
              <Button variant="hero" size="lg" asChild>
                <a href="/contact">Apply Now</a>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <a href="#departments">View Departments</a>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}