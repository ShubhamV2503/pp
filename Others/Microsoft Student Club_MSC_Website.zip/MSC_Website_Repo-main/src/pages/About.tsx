import { Award, Target, Heart, Users, Calendar, ExternalLink } from "lucide-react";
import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import Layout from "@/components/layout/Layout";
import mscLogo from "@/assets/msc-logo.jpeg";
/* ---------------- CONTRIBUTORS ---------------- */

const contributors = [
  {
    name: "Eshan Shukla",
    role: "Head (Research & Development)",
  },
  {
    name: "Sia Nair",
    role: "Head (Research & Development)",
  },
  {
    name: "Arnav Iyer",
    role: "Sub Head (Research & Development)",
  },
  {
    name: "Simran Ramchandani",
    role: "Sub Head (Research & Development)",
  },
  {
    name: "Vinayak Rastogi",
    role: "Sub Head (Research & Development)",
  },
  {
    name: "Jal Bafna",
    role: "Sub Head (Research & Development)",
  },
];

const milestones = [
  {
    year: "2024",
    title: "Club Establishment",
    description: "Microsoft Student Club established through collaboration between Microsoft and NMIMS.",
  },
  {
    year: "2024",
    title: "First Event",
    description: "Successfully organized Equinox 1.0 with 350+ participants and 95% positive feedback.",
  },
  {
    year: "2024",
    title: "Growing Community",
    description: "Building a vibrant community of tech enthusiasts across multiple departments.",
  },
];

const values = [
  {
    icon: Target,
    title: "Innovation",
    description: "We foster creativity and encourage exploring emerging technologies to solve real-world problems.",
  },
  {
    icon: Users,
    title: "Collaboration",
    description: "We believe in the power of teamwork and building meaningful connections within our community.",
  },
  {
    icon: Heart,
    title: "Inclusivity",
    description: "We create a welcoming environment where every member can contribute and grow regardless of their background.",
  },
  {
    icon: Award,
    title: "Excellence",
    description: "We strive for the highest standards in everything we do, from events to learning experiences.",
  },
];

export default function About() {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-hero py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-4xl text-center">
            <div className="mb-8 flex justify-center">
              <img 
                className="h-24 w-auto rounded-2xl shadow-glow float" 
                src={mscLogo} 
                alt="Microsoft Student Club MPSTME" 
              />
            </div>
            <h1 className="text-5xl font-extrabold tracking-tight text-foreground sm:text-7xl mb-4">
              About <span className="gradient-text">MSC, MPSTME</span>
            </h1>
            <p className="mt-4 text-xl leading-8 text-foreground-muted max-w-2xl mx-auto">
              <span className="font-semibold text-primary">A launchpad for leadership, innovation, and personal growth.</span> <br />
              We bring together tech enthusiasts, innovators, and leaders under one roof.
            </p>
          </div>
          {/* Timeline section is rendered below with milestones */}
        </div>
      </section>
       {/* Website Contributors */}
       <section className="py-16 sm:py-20 bg-background-secondary">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Website Contributors
            </h2>
            <p className="mt-4 text-lg leading-8 text-foreground-muted">
              We acknowledge the efforts of the members who contributed to the design and development of this website.
            </p>
          </div>

          <div className="mx-auto mt-12 max-w-3xl">
            <Card className="bg-gradient-card border-card-border">
              <CardContent className="divide-y divide-card-border">
                {contributors.map((person, index) => (
                  <div
                    key={index}
                    className="flex flex-col sm:flex-row sm:items-center sm:justify-between py-4"
                  >
                    <span className="font-medium text-foreground">
                      {person.name}
                    </span>
                    <span className="text-sm text-foreground-muted mt-1 sm:mt-0">
                      {person.role}
                    </span>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto grid max-w-2xl grid-cols-1 gap-x-8 gap-y-16 lg:mx-0 lg:max-w-none lg:grid-cols-2">
            <Card className="bg-gradient-card border-card-border card-hover">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                    <Target className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-2xl text-foreground">Our Vision</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-foreground-muted leading-7">
                  To create a vibrant and inclusive community of tech enthusiasts passionate about learning, building, and leading. We envision a platform where students explore emerging technologies, develop real-world skills, and grow into future leaders. Through collaboration and innovation, we aim to inspire every member to reach their potential and contribute meaningfully to society.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-card border-card-border card-hover">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                    <Heart className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-2xl text-foreground">Our Mission</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-foreground-muted leading-7">
                  Our mission is to bridge the gap between classroom learning and industry needs by offering hands-on experiences, mentorship, and leadership opportunities. We organize impactful events, workshops, and projects that encourage learning, creativity, and collaboration. By fostering a culture of curiosity and teamwork, we empower students to turn ideas into action and technology into impact.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>


      {/* Values Section - fixed wrapping */}
      <section className="py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Our Values
            </h2>

            <p className="mt-6 text-lg leading-8 text-foreground-muted">
              The principles that guide everything we do and shape our community culture.
            </p>
          </div>
          <div className="mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-8 sm:grid-cols-2 lg:mx-0 lg:max-w-none lg:grid-cols-4">
            {values.map((value, index) => (
              <Card 
                key={value.title} 
                className="bg-gradient-card border-card-border card-hover animate-scale-in text-center"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardHeader>
                  <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                    <value.icon className="h-8 w-8 text-primary" />
                  </div>
                  <CardTitle className="text-xl text-foreground">{value.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-foreground-muted text-sm leading-6">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-16 sm:py-24 bg-background-secondary">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Our Journey
            </h2>
            <p className="mt-6 text-lg leading-8 text-foreground-muted">
              Key milestones in the development of our community.
            </p>
          </div>
          <div className="mx-auto mt-16 max-w-4xl">
            <div className="space-y-8">
              {milestones.map((milestone, index) => (
                <div 
                  key={index} 
                  className="relative flex gap-6 animate-fade-in"
                  style={{ animationDelay: `${index * 0.2}s` }}
                >
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 ring-8 ring-background-secondary">
                    <Calendar className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3">
                      <span className="inline-flex items-center rounded-full bg-primary/20 px-3 py-1 text-xs font-medium text-primary">
                        {milestone.year}
                      </span>
                      <h3 className="text-lg font-semibold text-foreground">{milestone.title}</h3>
                    </div>
                    <p className="mt-2 text-foreground-muted">{milestone.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
              Ready to Join Our Community?
            </h2>
            <p className="mt-6 text-lg leading-8 text-foreground-muted">
              Be part of the next generation of tech leaders. Connect, learn, and innovate with us.
            </p>
            <div className="mt-10 flex items-center justify-center gap-6">
              <Button variant="hero" size="lg" asChild>
                <a href="/contact">Join MSC Today</a>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <a href="/committee">Meet Our Team</a>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}