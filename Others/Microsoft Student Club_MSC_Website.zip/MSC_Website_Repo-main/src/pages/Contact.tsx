import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Mail, Phone, MapPin, Send, Github, Instagram, Linkedin, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import Layout from "@/components/layout/Layout";

const contactInfo = [
  {
    icon: Mail,
    title: "Email",
    details: "msc.mpstme@outlook.com",
    href: "#",
  },
  {
    icon: MapPin,
    title: "Location",
    details: "MPSTME, NMIMS University, Mumbai",
    href: "https://www.google.com/maps/place/Mukesh+Patel+School+of+Technology+Management+%26+Engineering,+Mumbai/@19.1079319,72.8369676,17z/data=!4m15!1m8!3m7!1s0x3be7c9b888ae67fd:0xe0b9538d623ac5d2!2sMukesh+Patel+School+of+Technology+Management+%26+Engineering,+Mumbai!8m2!3d19.1079172!4d72.8371219!10e5!16s%2Fm%2F011l5z37!3m5!1s0x3be7c9b888ae67fd:0xe0b9538d623ac5d2!8m2!3d19.1079172!4d72.8371219!16s%2Fm%2F011l5z37?entry=ttu&g_ep=EgoyMDI1MDkyNC4wIKXMDSoASAFQAw%3D%3D",
  },
];

const socialLinks = [
  {
    name: "LinkedIn",
    href: "https://www.linkedin.com/company/msc-mpstme/posts/?feedView=all",
    icon: Linkedin,
    color: "hover:text-blue-500",
  },
  {
    name: "Instagram",
    href: "https://www.instagram.com/msc_mpstme/", 
    icon: Instagram,
    color: "hover:text-pink-500",
  },
  {
    name: "GitHub",
    href: "https://github.com/Microsoft-Student-Club-MPSTME",
    icon: Github,
    color: "hover:text-foreground",
  },
];

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });
  const { toast } = useToast();

  const [submitted, setSubmitted] = useState(false);
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    toast({
      title: "Message Sent!",
      description: "Thank you for reaching out. We'll get back to you soon.",
    });
    setTimeout(() => setSubmitted(false), 1800);
    setFormData({ name: "", email: "", subject: "", message: "" });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };


  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-hero py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-4xl text-center">
            <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-6xl">
              Get In <span className="gradient-text">Touch</span>
            </h1>
            <p className="mt-6 text-lg leading-8 text-foreground-muted max-w-2xl mx-auto">
              Have questions about MSC MPSTME? Want to join our community? We'd love to hear from you.
            </p>
          </div>
        </div>
      </section>

      {/* Redesigned Contact Section */}
      <section className="relative py-20 sm:py-28 bg-background-secondary/80">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/10 to-primary/5 pointer-events-none" aria-hidden />
        <div className="relative mx-auto max-w-7xl px-4 sm:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-stretch">
            {/* Contact Form */}
            <Card className="flex flex-col justify-center bg-gradient-card border-card-border card-hover shadow-2xl h-full min-h-[520px]">
              <CardHeader>
                <CardTitle className="text-3xl text-primary mb-2">Send us a message</CardTitle>
                <CardDescription className="text-foreground-muted">
                  Fill out the form below and we'll get back to you as soon as possible.
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-1 flex flex-col justify-center">
                <form onSubmit={handleSubmit} className="space-y-6">
                  <AnimatePresence>
                    {submitted && (
                      <motion.div
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 20 }}
                        className="mb-2 text-center text-green-600 font-semibold"
                      >
                        Thank you for your message!
                      </motion.div>
                    )}
                  </AnimatePresence>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="name" className="text-foreground">Name</Label>
                      <Input
                        id="name"
                        name="name"
                        type="text"
                        placeholder="Your name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                        className="bg-background-tertiary border-card-border text-foreground"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-foreground">Email</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        placeholder="your.email@example.com"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="bg-background-tertiary border-card-border text-foreground"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="subject" className="text-foreground">Subject</Label>
                    <Input
                      id="subject"
                      name="subject"
                      type="text"
                      placeholder="What's this about?"
                      value={formData.subject}
                      onChange={handleChange}
                      required
                      className="bg-background-tertiary border-card-border text-foreground"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="message" className="text-foreground">Message</Label>
                    <Textarea
                      id="message"
                      name="message"
                      placeholder="Tell us more about your inquiry..."
                      value={formData.message}
                      onChange={handleChange}
                      required
                      className="min-h-[120px] bg-background-tertiary border-card-border text-foreground"
                    />
                  </div>
                  <motion.div
                    whileHover={{ scale: 1.04, backgroundColor: "#2563eb", color: "#fff" }}
                    whileTap={{ scale: 0.97 }}
                    transition={{ type: "spring", stiffness: 300, damping: 20 }}
                  >
                    <Button type="submit" variant="hero" size="lg" className="w-full">
                      Send Message
                      <Send className="ml-2 h-4 w-4" />
                    </Button>
                  </motion.div>
                </form>
              </CardContent>
            </Card>

            {/* Contact Information & Links */}
            <div className="flex flex-col gap-8 justify-center h-full">
              <Card className="bg-gradient-card border-card-border card-hover">
                <CardHeader>
                  <CardTitle className="text-2xl text-foreground">Contact Information</CardTitle>
                  <CardDescription className="text-foreground-muted">
                    Reach out to us through any of these channels. We're here to help and answer your questions.
                  </CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col gap-4">
                  {contactInfo.map((item, index) => (
                    <div key={index} className="flex items-center gap-4">
                      <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                        <item.icon className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground">{item.title}</h3>
                        {item.href !== "#" ? (
                          <a
                            href={item.href}
                            className="text-foreground-muted hover:text-primary transition-colors"
                            target="_blank"
                          >
                            {item.details}
                          </a>
                        ) : (
                          <p className="text-foreground-muted">{item.details}</p>
                        )}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card className="bg-gradient-card border-card-border card-hover">
                <CardHeader>
                  <CardTitle className="text-xl text-foreground">Follow Us</CardTitle>
                  <CardDescription className="text-foreground-muted">
                    Stay connected with our latest updates and activities.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-4">
                    {socialLinks.map((link, index) => (
                      <a
                        key={index}
                        href={link.href}
                        className={`flex h-12 w-12 items-center justify-center rounded-lg bg-secondary/50 text-foreground-muted transition-colors ${link.color}`}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <link.icon className="h-5 w-5" />
                        <span className="sr-only">{link.name}</span>
                      </a>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-card border-card-border card-hover">
                <CardHeader>
                  <CardTitle className="text-xl text-foreground">Quick Links</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <a
                      href="https://learn.microsoft.com"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2 text-foreground-muted hover:text-primary transition-colors"
                    >
                      Microsoft Learn
                      <ExternalLink className="h-4 w-4" />
                    </a>
                    <a
                      href="/about"
                      className="flex items-center gap-2 text-foreground-muted hover:text-primary transition-colors"
                    >
                      About MSC MPSTME
                    </a>
                    <a
                      href="/events"
                      className="flex items-center gap-2 text-foreground-muted hover:text-primary transition-colors"
                    >
                      Upcoming Events
                    </a>
                    <a
                      href="/committee"
                      className="flex items-center gap-2 text-foreground-muted hover:text-primary transition-colors"
                    >
                      Join Our Team
                    </a>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 sm:py-24 bg-background-secondary">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-4xl">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                Frequently Asked Questions
              </h2>
              <p className="mt-6 text-lg leading-8 text-foreground-muted">
                Quick answers to common questions about MSC MPSTME.
              </p>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              <Card className="bg-gradient-card border-card-border">
                <CardHeader>
                  <CardTitle className="text-lg text-foreground">How can I join MSC MPSTME?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-foreground-muted text-sm">
                    Simply fill out our contact form or reach out via email. We welcome students from all backgrounds who are passionate about technology and innovation.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-card border-card-border">
                <CardHeader>
                  <CardTitle className="text-lg text-foreground">What events do you organize?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-foreground-muted text-sm">
                    We organize workshops, hackathons, guest talks, networking sessions, and flagship events like Equinox. Check our events page for upcoming activities.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-card border-card-border">
                <CardHeader>
                  <CardTitle className="text-lg text-foreground">Are there leadership opportunities?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-foreground-muted text-sm">
                    Yes! We have various departments and leadership positions available. From core team roles to department heads, there are many ways to get involved.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-card border-card-border">
                <CardHeader>
                  <CardTitle className="text-lg text-foreground">Do I need prior tech experience?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-foreground-muted text-sm">
                    Not at all! We welcome members with all levels of experience. Our community is designed to help you learn and grow, regardless of your starting point.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}