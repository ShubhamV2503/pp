import { Link } from "react-router-dom";
import { Github, Instagram, Linkedin, Mail, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import mscLogo from "@/assets/msc-logo.jpeg";

const footerNavigation = {
  main: [
    { name: "About", href: "/about" },
    { name: "Events", href: "/events" },
    { name: "Resources", href: "/resources" },
    { name: "Team", href: "/team" },
    { name: "Contact", href: "/contact" },
  ],
  resources: [
    { name: "Microsoft Learn", href: "https://learn.microsoft.com", external: true },
    { name: "Azure AI Studio", href: "https://azure.microsoft.com/en-us/products/ai-studio", external: true },
    { name: "GitHub Copilot", href: "https://github.com/features/copilot", external: true },
    { name: "Annual Report", href: "/resources" },
  ],
  social: [
    {
      name: "LinkedIn",
      href: "https://www.linkedin.com/company/msc-mpstme/posts/?feedView=all",
      icon: Linkedin,
    },
    {
      name: "Instagram", 
      href: "https://www.instagram.com/msc_mpstme/",
      icon: Instagram,
    },
    {
      name: "GitHub",
      href: "https://github.com/Microsoft-Student-Club-MPSTME",
      icon: Github,
    },
    {
      name: "Email",
      href: "mailto:msc.mpstme@outlook.com",
      icon: Mail,
    },
  ],
};

export default function Footer() {
  return (
    <footer className="bg-background-secondary border-t border-card-border">
      <div className="mx-auto max-w-7xl px-6 pb-8 pt-16 sm:pt-24 lg:px-8">
        <div className="xl:grid xl:grid-cols-3 xl:gap-8">
          <div className="space-y-8">
            <div className="flex items-center space-x-3">
              <img className="h-12 w-auto rounded-lg" src={mscLogo} alt="MSC MPSTME" />
              <div>
                <div className="text-xl font-bold text-foreground">Microsoft Student Club</div>
                <div className="text-sm text-foreground-muted">MPSTME, NMIMS University</div>
              </div>
            </div>
            <p className="text-sm leading-6 text-foreground-muted">
              Innovating Today, Empowering Tomorrow. Building the next generation of tech leaders through collaboration, learning, and innovation.
            </p>
            <div className="flex space-x-6">
              {footerNavigation.social.map((item) => (
              <a
              key={item.name}
              href={item.href}
              target="_blank"
              rel="noopener noreferrer"
              className="text-foreground-muted hover:text-primary transition-colors"
              >
              <span className="sr-only">{item.name}</span>
              <item.icon className="h-6 w-6" />
              </a>
              ))}
            </div>

          </div>
          <div className="mt-16 grid grid-cols-2 gap-8 xl:col-span-2 xl:mt-0">
            <div className="md:grid md:grid-cols-2 md:gap-8">
              <div>
                <h3 className="text-sm font-semibold leading-6 text-foreground">Navigation</h3>
                <ul role="list" className="mt-6 space-y-4">
                  {footerNavigation.main.map((item) => (
                    <li key={item.name}>
                      <Link
                        to={item.href}
                        className="text-sm leading-6 text-foreground-muted hover:text-primary transition-colors"
                      >
                        {item.name}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="mt-10 md:mt-0">
                <h3 className="text-sm font-semibold leading-6 text-foreground">Resources</h3>
                <ul role="list" className="mt-6 space-y-4">
                  {footerNavigation.resources.map((item) => (
                    <li key={item.name}>
                      {item.external ? (
                        <a
                          href={item.href}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-sm leading-6 text-foreground-muted hover:text-primary transition-colors inline-flex items-center gap-1"
                        >
                          {item.name}
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      ) : (
                        <Link
                          to={item.href}
                          className="text-sm leading-6 text-foreground-muted hover:text-primary transition-colors"
                        >
                          {item.name}
                        </Link>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div className="section-divider" />
        <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
          <p className="text-xs leading-5 text-foreground-muted">
            &copy; {new Date().getFullYear()} Microsoft Student Club, MPSTME. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <Button variant="glass" size="sm" asChild>
              <a href="mailto:msc.mpstme@outlook.com">
                Get In Touch
              </a>
            </Button>
            <Button variant="outline" size="sm" asChild>
              <Link to="/contact">
                Join Us
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </footer>
  );
}