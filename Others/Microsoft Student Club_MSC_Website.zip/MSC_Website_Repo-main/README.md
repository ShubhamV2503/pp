Donwload git for command line.

Download Node:

For Windows/ Mac users download Node from website.

For Linux users find the respective commnds for your distribution.



Follow these steps:

```sh
# Step 1: 
gh repo clone Arnav-debug07/MSC_Website_Repo
# Step 2: .
cd MSC_Website_Repo

# Step 3:
npm i

# Step 4: 
npm run dev
```

