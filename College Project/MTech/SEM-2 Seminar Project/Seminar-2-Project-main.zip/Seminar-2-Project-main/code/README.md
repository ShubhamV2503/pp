---
title: Gmail AI Agent
sdk: gradio
sdk_version: 5.38.0
python_version: 3.11
app_file: app.py
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
